# REDX Courier

## Auth

- API token
- Production base URL: openapi.redx.com.bd/v1.0.0-beta

## Main Features

- Create parcel
- Update parcel
- Track parcel
- Get parcel details
- Calculate parcel charge
- Get areas
- Pickup store
- Webhook status update
