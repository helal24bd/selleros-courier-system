# Courier Integration Documentation

This folder explains how each courier works inside SellerOS.

## Common Flow

1. Seller selects/configures courier.
2. Seller sets one courier as active.
3. Seller clicks **Move To Courier** from order details.
4. System sends order data to active courier API.
5. Courier returns tracking/consignment data.
6. SellerOS saves courier response.
7. Courier webhook updates delivery status later.

## Common Methods

Every courier service should support:

```php
createParcel($order);
trackParcel($trackingId);
cancelParcel($trackingId);
```
