# Webhook Events

Normalize all courier webhook statuses into common SellerOS statuses:

- pending
- approved
- picked
- in_transit
- out_for_delivery
- delivered
- partial_delivered
- returned
- cancelled
- hold
- failed

Each webhook controller should:

1. Log raw payload.
2. Verify signature/secret if available.
3. Find order by tracking ID or reference.
4. Update `courier_status`.
5. Save raw payload in `courier_response`.
