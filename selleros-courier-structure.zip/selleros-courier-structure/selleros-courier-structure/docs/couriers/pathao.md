# Pathao Courier

## Auth

- Client ID
- Client Secret
- Username
- Password
- Token based authentication

## Main Features

- Issue access token
- Refresh token
- Create store
- Get city, zone, area
- Create order
- Price calculation
- Track order

## Notes

Pathao requires location mapping before order creation.
