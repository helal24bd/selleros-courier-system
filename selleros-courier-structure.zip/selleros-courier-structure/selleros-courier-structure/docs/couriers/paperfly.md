# Paperfly Courier

## Auth

- Basic Auth: merchant username + password
- Paperfly header/API key if provided

## Main Features

- Create order
- Exchange order
- Tracking
- Cancel order
- Webhook event notifications

## Common Events

- parcel_created
- parcel_invoiced
- parcel_cancelled
- parcel_picked_up
- parcel_in_transit
- parcel_delivered
- parcel_partial
- parcel_exchange
- parcel_on_hold
- parcel_return
