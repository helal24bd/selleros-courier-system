# Database Structure

## couriers table

Required fields:

- store_id
- name
- slug
- api_url
- api_key
- secret_key
- client_id
- client_secret
- username
- password
- token
- store_id_key
- merchant_id
- phone
- extra_fields
- is_active
- status

## orders table suggested courier fields

- courier_id
- courier_name
- courier_tracking_id
- courier_consignment_id
- courier_status
- courier_charge
- courier_response
- courier_synced_at
