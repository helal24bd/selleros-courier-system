# Steadfast Courier

## Auth

- API Key
- Secret Key
- Content-Type: application/json

## Main Features

- Create order/parcel
- Bulk order
- Tracking by consignment ID, invoice or tracking code
- Balance check
- Status API

## Notes

Steadfast is usually the easiest courier to integrate first.
