# CarryBee Courier

## Auth

- Client ID
- Client Secret
- Client Context

## Main Features

- Get cities
- Get zones
- Get areas
- Create store
- Create single order
- Create bulk order
- Cancel order
- Get order details
- Webhooks

## Notes

CarryBee has rich location and webhook support.
