<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use App\Services\Couriers\Contracts\CourierInterface;
use Illuminate\Support\Facades\Http;

class PaperflyCourierService implements CourierInterface
{
    public function __construct(private Courier $courier)
    {
    }

    public function createParcel($order): array
    {
        // TODO: Map SellerOS order data to Paperfly API payload.
        // TODO: Send HTTP request and return normalized response.
        return [
            'success' => false,
            'message' => 'Paperfly createParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function trackParcel(string $trackingId): array
    {
        // TODO: Call Paperfly tracking API.
        return [
            'success' => false,
            'message' => 'Paperfly trackParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function cancelParcel(string $trackingId): array
    {
        // TODO: Call Paperfly cancel API.
        return [
            'success' => false,
            'message' => 'Paperfly cancelParcel not implemented yet.',
            'data' => [],
        ];
    }
}
