<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use App\Services\Couriers\Contracts\CourierInterface;
use Illuminate\Support\Facades\Http;

class RedxCourierService implements CourierInterface
{
    public function __construct(private Courier $courier)
    {
    }

    public function createParcel($order): array
    {
        // TODO: Map SellerOS order data to Redx API payload.
        // TODO: Send HTTP request and return normalized response.
        return [
            'success' => false,
            'message' => 'Redx createParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function trackParcel(string $trackingId): array
    {
        // TODO: Call Redx tracking API.
        return [
            'success' => false,
            'message' => 'Redx trackParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function cancelParcel(string $trackingId): array
    {
        // TODO: Call Redx cancel API.
        return [
            'success' => false,
            'message' => 'Redx cancelParcel not implemented yet.',
            'data' => [],
        ];
    }
}
