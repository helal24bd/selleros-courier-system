<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use App\Services\Couriers\Contracts\CourierInterface;
use Illuminate\Support\Facades\Http;

class SteadfastCourierService implements CourierInterface
{
    public function __construct(private Courier $courier)
    {
    }

    public function createParcel($order): array
    {
        // TODO: Map SellerOS order data to Steadfast API payload.
        // TODO: Send HTTP request and return normalized response.
        return [
            'success' => false,
            'message' => 'Steadfast createParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function trackParcel(string $trackingId): array
    {
        // TODO: Call Steadfast tracking API.
        return [
            'success' => false,
            'message' => 'Steadfast trackParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function cancelParcel(string $trackingId): array
    {
        // TODO: Call Steadfast cancel API.
        return [
            'success' => false,
            'message' => 'Steadfast cancelParcel not implemented yet.',
            'data' => [],
        ];
    }
}
