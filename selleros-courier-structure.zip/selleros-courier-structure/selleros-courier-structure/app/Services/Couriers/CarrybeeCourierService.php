<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use App\Services\Couriers\Contracts\CourierInterface;
use Illuminate\Support\Facades\Http;

class CarrybeeCourierService implements CourierInterface
{
    public function __construct(private Courier $courier)
    {
    }

    public function createParcel($order): array
    {
        // TODO: Map SellerOS order data to Carrybee API payload.
        // TODO: Send HTTP request and return normalized response.
        return [
            'success' => false,
            'message' => 'Carrybee createParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function trackParcel(string $trackingId): array
    {
        // TODO: Call Carrybee tracking API.
        return [
            'success' => false,
            'message' => 'Carrybee trackParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function cancelParcel(string $trackingId): array
    {
        // TODO: Call Carrybee cancel API.
        return [
            'success' => false,
            'message' => 'Carrybee cancelParcel not implemented yet.',
            'data' => [],
        ];
    }
}
