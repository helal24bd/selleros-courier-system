<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use InvalidArgumentException;

class CourierManager
{
    public function service(Courier $courier)
    {
        return match ($courier->slug) {
            'steadfast' => new SteadfastCourierService($courier),
            'pathao' => new PathaoCourierService($courier),
            'redx' => new RedxCourierService($courier),
            'carrybee' => new CarrybeeCourierService($courier),
            'paperfly' => new PaperflyCourierService($courier),
            default => throw new InvalidArgumentException('Unsupported courier: '.$courier->slug),
        };
    }

    public function activeForStore(int $storeId): ?Courier
    {
        return Courier::where('store_id', $storeId)
            ->where('is_active', true)
            ->where('status', true)
            ->first();
    }
}
