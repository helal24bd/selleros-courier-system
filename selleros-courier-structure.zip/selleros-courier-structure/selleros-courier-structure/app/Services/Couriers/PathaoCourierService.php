<?php

namespace App\Services\Couriers;

use App\Models\Courier;
use App\Services\Couriers\Contracts\CourierInterface;
use Illuminate\Support\Facades\Http;

class PathaoCourierService implements CourierInterface
{
    public function __construct(private Courier $courier)
    {
    }

    public function createParcel($order): array
    {
        // TODO: Map SellerOS order data to Pathao API payload.
        // TODO: Send HTTP request and return normalized response.
        return [
            'success' => false,
            'message' => 'Pathao createParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function trackParcel(string $trackingId): array
    {
        // TODO: Call Pathao tracking API.
        return [
            'success' => false,
            'message' => 'Pathao trackParcel not implemented yet.',
            'data' => [],
        ];
    }

    public function cancelParcel(string $trackingId): array
    {
        // TODO: Call Pathao cancel API.
        return [
            'success' => false,
            'message' => 'Pathao cancelParcel not implemented yet.',
            'data' => [],
        ];
    }
}
