<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\Couriers\CourierManager;
use Illuminate\Http\Request;

class CourierOrderController extends Controller
{
    public function moveToCourier(Request $request, Order $order, CourierManager $manager)
    {
        $storeId = auth()->user()->store->id;

        if ((int) $order->store_id !== (int) $storeId) {
            abort(403);
        }

        $courier = $manager->activeForStore($storeId);

        if (!$courier) {
            return back()->with('error', 'No active courier found.');
        }

        $service = $manager->service($courier);
        $response = $service->createParcel($order);

        // TODO: Save normalized tracking response to order table.

        return back()->with(
            $response['success'] ? 'success' : 'error',
            $response['message'] ?? 'Courier request completed.'
        );
    }
}
