<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaperflyWebhookController extends Controller
{
    public function handle(Request $request)
    {
        Log::info('Paperfly Webhook Received', $request->all());

        // TODO: Verify webhook secret/signature if available.
        // TODO: Find order by tracking ID/reference.
        // TODO: Update courier_status and courier_response.

        return response()->json([
            'success' => true,
            'message' => 'Paperfly webhook received.',
        ]);
    }
}
